# Real-or-Not-Disaster-Tweets
Checking if the Disaster Tweets are Real or Fake using Natural Language Processing(NLP).
